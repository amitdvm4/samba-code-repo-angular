//this file is the main server file
//node starts the execution from server.js file
//import express module
let express = require("express");
//import body-parser
let bodyparser = require("body-parser");
//import cors module
//cors module used to enable the ports communication
let cors = require("cors");
//create the rest object
let app = express();
//set the JSON as MIME Type
app.use(bodyparser.json());
//read the non extended parameters
app.use(bodyparser.urlencoded({extended:false}));
//enable the ports communication
app.use(cors());
//import module1
let module1 = require("./fetch/fetch");
//use the module1
app.use("/fetch",module1);
//import module2
let module2 = require("./insert/insert");
//use the module2
app.use("/insert",module2);
//import module3
let module3 = require("./update/update");
//use the module3
app.use("/update",module3);
//import module4
let module4 = require("./delete/delete");
//use the module4
app.use("/delete",module4);
//assign the port no
app.listen(8080);
console.log("server listening the port no.8080");