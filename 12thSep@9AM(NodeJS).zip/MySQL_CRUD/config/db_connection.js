//this file used to create and return the mysql connection object
//import mysql module
let mysql = require("mysql");
//import db_properties
let db_prop = require("./db_properties");
//create the JSON Object
let obj = {
    "connection":()=>{
        return mysql.createConnection(db_prop);
    }
};
//export the JSON Object
module.exports = obj;