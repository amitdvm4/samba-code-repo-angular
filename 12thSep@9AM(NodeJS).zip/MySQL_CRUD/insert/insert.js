//this file used to insert the data into products table
//import express module
let express = require("express");
//import db_connection
let obj = require("../config/db_connection");
//get the connection object
let connection = obj.connection();
//connect to database
connection.connect();
//import queries
let obj1 = require("../config/queries");
//create the module
let module2 = express.Router().post("/",(req,res)=>{
    obj1.insert(connection,req,res);
});
//export module2
module.exports = module2;