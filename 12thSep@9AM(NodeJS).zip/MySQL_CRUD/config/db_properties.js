//this file used to maintain the MySQL database credentials
const obj = {
    "host":"localhost",
    "user":"root",
    "password":"root",
    "database":"nodedb"
};
module.exports = obj;